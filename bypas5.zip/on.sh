#!/system/bin/sh

su -c iptables -F
iptables -F
su -c iptables --flush
iptables --flush
iptables -F
iptables -X
ip6tables --flush
ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
iptables -I INPUT -p tcp --dport 80 -j DROP
iptables -I INPUT -p tcp --dport 8080 -j DROP
iptables -I INPUT -p tcp --dport 18081 -j DROP
iptables -I INPUT -p tcp --dport 3013 -j DROP
iptables -I INPUT -p tcp --dport 1112 -j DROP
iptables -I INPUT -p tcp --dport 11443 -j DROP
iptables -I INPUT -p tcp --dport 17500 -j DROP
iptables -I OUTPUT -p tcp --dport 17500 -j DROP
iptables -I OUTPUT -p tcp --dport 80 -j DROP
iptables -I OUTPUT -p tcp --dport 8080 -j DROP
iptables -I OUTPUT -p tcp --dport 18081 -j DROP
iptables -I OUTPUT -p tcp --dport 3013 -j DROP
iptables -I OUTPUT -p tcp --dport 1112 -j DROP
iptables -I OUTPUT -p tcp --dport 11443 -j DROP
iptables -I OUTPUT -p udp --dport 81 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 111 -j DROP
iptables -I OUTPUT -p udp --dport 11038 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 20001 -j DROP
iptables -I INPUT -p tcp --dport 80 -j REJECT
iptables -I INPUT -p tcp --dport 8080 -j REJECT
iptables -I INPUT -p tcp --dport 8085 -j REJECT
iptables -I INPUT -p tcp --dport 8086 -j REJECT
iptables -I INPUT -p tcp --dport 8088 -j REJECT
iptables -I INPUT -p tcp --dport 18081 -j REJECT
iptables -I INPUT -p tcp --dport 3013 -j REJECT
iptables -I INPUT -p tcp --dport 1112 -j REJECT
iptables -I INPUT -p tcp --dport 11443 -j REJECT
iptables -I INPUT -p tcp --dport 17500 -j REJECT
iptables -I OUTPUT -p tcp --dport 17500 -j REJECT
iptables -I OUTPUT -p tcp --dport 80 -j REJECT
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT
iptables -I OUTPUT -p tcp --dport 8085 -j REJECT
iptables -I OUTPUT -p tcp --dport 8086 -j REJECT
iptables -I OUTPUT -p tcp --dport 8088 -j REJECT
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
iptables -I OUTPUT -p tcp --dport 3013 -j REJECT
iptables -I OUTPUT -p tcp --dport 1112 -j REJECT
iptables -I OUTPUT -p tcp --dport 11443 -j REJECT
report(){
VER=$1
RES="/storage/emulated/0/android/data/$VER/files"
rm -rf $RES/TGPA
echo "@ANONYMOUS_MODSX" > TGPA; chmod 000 TGPA ; mv TGPA $RES/
rm -rf $RES/ProgramBinaryCache
echo "@ANONYMOUS_MODSX" > ProgramBinaryCache; chmod 000 ProgramBinaryCache ; mv ProgramBinaryCache $RES/
rm -rf $RES/UE4Game/ShadowTrackerExtra/Engine
rm -rf $RES/UE4Game/ShadowTrackerExtra/'Epic Games'
echo "@ANONYMOUS_MODSX" > Engine ; chmod 000 Engine; mv Engine $RES/UE4Game/ShadowTrackerExtra/
echo "@ANONYMOUS_MODSX" > 'Epic Games'; chmod 000 'Epic Games';mv 'Epic Games' $RES/UE4Game/ShadowTrackerExtra/
echo "@ANONYMOUS_MODSX" > cache ; chmod 0550 cache; mv cache /sdcard/Android/data/$VER/
am start -n $VER/com.epicgames.ue4.SplashActivity
}
VER=$1
if [ "$VER" != "" ];then
iptables -A INPUT -m string --algo bm --string "report" -j DROP
iptables -A OUTPUT -m string --algo bm --string "report" -j DROP
iptables -A FORWARD -m string --algo bm --string "report" -j DROP
iptables -A INPUT -m string --algo bm --string "Report" -j DROP
iptables -A OUTPUT -m string --algo bm --string "Report" -j DROP
iptables -A FORWARD -m string --algo bm --string "Report" -j DROP
sleep 3
report $VER
else
printf "HOW TO:\n\
bypass_report.sh com.tencent.ig\n\
bypass_report.sh com.pubg.imobile\n\
bypass_report.sh com.vng.pubgmobile\n\
bypass_report.sh com.rekoo.pubgm\n\
bypass_report.sh com.pubg.krmobile\n"
iptables -A INPUT -m string --algo bm --string "report" -j ACCEPT
iptables -A OUTPUT -m string --algo bm --string "report" -j ACCEPT
iptables -A FORWARD -m string --algo bm --string "report" -j ACCEPT
iptables -A INPUT -m string --algo bm --string "Report" -j ACCEPT
iptables -A OUTPUT -m string --algo bm --string "Report" -j ACCEPT
iptables -A FORWARD -m string --algo bm --string "Report" -j ACCEPT
fi
sleep 5
while :
do
  kill $(ps -A | grep -E 'com.pubg.imobile:plugin' | awk '{print $2}')
  sleep 4
done
